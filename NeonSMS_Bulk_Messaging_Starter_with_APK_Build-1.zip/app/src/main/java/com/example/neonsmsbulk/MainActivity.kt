package com.example.neonsmsbulk

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import android.text.InputType

class MainActivity : Activity() {
    private val bg = Color.rgb(5, 10, 8)
    private val panel = Color.rgb(13, 25, 19)
    private val neon = Color.rgb(57, 255, 130)
    private val soft = Color.rgb(170, 205, 180)
    private lateinit var phoneList: EditText
    private lateinit var message: EditText
    private lateinit var consent: CheckBox
    private lateinit var log: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(18))
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val title = TextView(this).apply {
            text = "NEON // SMS"
            textSize = 27f
            setTextColor(neon)
            typeface = Typeface.MONOSPACE
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(2))
        }
        body.addView(title)
        val subtitle = TextView(this).apply {
            text = "BULK MESSAGING CONSOLE"
            textSize = 12f
            setTextColor(soft)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(18))
        }
        body.addView(subtitle)

        body.addView(label("01  /  RECIPIENT NUMBERS"))
        phoneList = EditText(this).apply {
            hint = "One number per line, e.g. +98912xxxxxxx"
            setHintTextColor(Color.rgb(95, 125, 105))
            setTextColor(neon)
            textSize = 14f
            typeface = Typeface.MONOSPACE
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 4
            gravity = Gravity.TOP
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(panel)
        }
        body.addView(phoneList, params())

        body.addView(label("02  /  MESSAGE"))
        message = EditText(this).apply {
            hint = "Write your message..."
            setHintTextColor(Color.rgb(95, 125, 105))
            setTextColor(Color.WHITE)
            textSize = 15f
            minLines = 3
            gravity = Gravity.TOP
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(panel)
        }
        body.addView(message, params())

        consent = CheckBox(this).apply {
            text = "All recipients have explicitly opted in to receive this message."
            setTextColor(soft)
            buttonTintList = android.content.res.ColorStateList.valueOf(neon)
            textSize = 13f
            setPadding(0, dp(8), 0, dp(8))
        }
        body.addView(consent)

        val send = Button(this).apply {
            text = "PREPARE SEND"
            setTextColor(bg)
            setBackgroundColor(neon)
            typeface = Typeface.MONOSPACE
            setOnClickListener { validateAndPreview() }
        }
        body.addView(send, params())

        val note = TextView(this).apply {
            text = "API STATUS: NOT CONFIGURED\\nThis starter project does not send real SMS yet. Connect an authorized SMS provider API and adapt its documented request format before enabling sending."
            setTextColor(soft)
            textSize = 12f
            typeface = Typeface.MONOSPACE
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(panel)
        }
        body.addView(note, params())

        log = TextView(this).apply {
            text = ">> READY\\n>> Offline preview only"
            setTextColor(neon)
            textSize = 13f
            typeface = Typeface.MONOSPACE
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        body.addView(log)
        setContentView(root)
    }

    private fun validateAndPreview() {
        val numbers = phoneList.text.toString().lines()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .distinct()
        val text = message.text.toString().trim()
        if (numbers.isEmpty()) {
            log.text = ">> ERROR: Enter at least one recipient."
            return
        }
        if (numbers.size > 100) {
            log.text = ">> BLOCKED: Starter limit is 100 recipients per batch."
            return
        }
        if (text.isBlank()) {
            log.text = ">> ERROR: Message cannot be empty."
            return
        }
        if (!consent.isChecked) {
            log.text = ">> BLOCKED: Confirm recipient consent before proceeding."
            return
        }
        log.text = ">> VALIDATION OK\\n>> Recipients: ${numbers.size}\\n>> Characters: ${text.length}\\n>> No messages sent.\\n>> Configure an authorized provider API to enable delivery."
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 12f
        setTextColor(neon)
        typeface = Typeface.MONOSPACE
        setPadding(0, dp(12), 0, dp(7))
    }

    private fun params() = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
        bottomMargin = dp(10)
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
